<?php
	class alunoController
	{
		public function listar()
		{
			echo "Estou no aluno e executei o método listar";
		}
		public function inserir()
		{
		}
		public function alterar()
		{
		}
	}//fim da classe
?>