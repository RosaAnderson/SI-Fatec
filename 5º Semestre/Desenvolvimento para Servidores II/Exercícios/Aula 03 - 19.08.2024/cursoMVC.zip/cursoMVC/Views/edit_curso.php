<!docytpe html>
<html>
	<head>
		<title>Formulário para Alteração de curso</title>
		<meta charset="UTF-8">
	</head>
	<body>
		<h1>Curso</h1>
		<form action="/cursoMVC/alterar" method="post">
			<input type="hidden" name="id_curso" value="<?php echo $retorno[0]->id_curso;?>">
			<label for="nome">Nome:</label>
			<input type="text" name="nome" id="nome" value="<?php echo $retorno[0]->nome;?>">
			<div><?php echo $msg;?></div>
			<br><br>
			<input type="submit">
		</form>
	</body>
</html>