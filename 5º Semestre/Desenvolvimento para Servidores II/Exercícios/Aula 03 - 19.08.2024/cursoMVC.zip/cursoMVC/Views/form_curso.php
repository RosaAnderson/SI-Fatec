<!docytpe html>
<html>
	<head>
		<title>Formulário para inclusão de curso</title>
		<meta charset="UTF-8">
	</head>
	<body>
		<h1>Curso</h1>
		<form action="/cursoMVC/inserir" method="post">
			<label for="nome">Nome:</label>
			<input type="text" name="nome" id="nome">
			<div><?php echo $msg;?></div>
			<br><br>
			<input type="submit">
		</form>
	</body>
</html>