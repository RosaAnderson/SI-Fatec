<?php
	require_once "Models/Conexao.class.php";
	require_once "Models/cursoDAO.class.php";
	require_once "Models/Curso.class.php";
	class cursoController
	{
		public function listar()
		{
			//buscar os cursos no BD
			$cursoDAO = new cursoDAO();
			$retorno = $cursoDAO->buscar_cursos();
			//var_dump($retorno);
			//mostrar em uma visão
			require_once "Views/listar_cursos.php";
		}
		public function inserir()
		{
			$msg = "";
			//inserir no banco de dados
			if($_POST)
			{
				if(empty($_POST["nome"]))
				{
					$msg = "Preencha o nome do curso";
				}
				else
				{
					//criar um objeto para carregar os dados
					$curso = new Curso(nome:$_POST["nome"]);
					$cursoDAO = new cursoDAO();
					$cursoDAO->inserir($curso);
					header("Location:index.php?controle=cursoController&metodo=listar");
					die();
				}
			}//if post
			//mostrar a visão
			require_once "Views/form_curso.php";
		}
		public function alterar()
		{
		}
		public function excluir()
		{
			if(isset($_GET["id"]))
			{
				$curso = new Curso($_GET["id"]);
				$cursoDAO = new cursoDAO();
				$cursoDAO->excluir($curso);
				header("Location:index.php?controle=cursoController&metodo=listar");
				die();
			}
		}
	}//fim da classe
?>