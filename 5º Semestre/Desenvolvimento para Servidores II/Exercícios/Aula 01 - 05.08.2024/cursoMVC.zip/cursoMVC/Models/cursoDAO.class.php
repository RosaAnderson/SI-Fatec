<?php
	class cursoDAO extends Conexao
	{
		public function __construct()
		{
			parent:: __construct();
		}
		
		public function buscar_cursos()
		{
			$sql = "SELECT * FROM cursos";
			try
			{
				$stm = $this->db->prepare($sql);
				$stm->execute();
				$this->db = null;
				return $stm->fetchAll(PDO::FETCH_OBJ); 
			}
			catch(PDOException $e)
			{
				$this->db = null;
				return "Problema ao buscar os cursos";
			}
		}
	}//fim classe
?>