<?php
	require_once "Models/Conexao.class.php";
	require_once "Models/cursoDAO.class.php";
	class cursoController
	{
		public function listar()
		{
			//buscar os cursos no BD
			$cursoDAO = new cursoDAO();
			$retorno = $cursoDAO->buscar_cursos();
			var_dump($retorno);
			//mostrar em uma visão
		}
		public function inserir()
		{
		}
		public function alterar()
		{
		}
	}//fim da classe
?>