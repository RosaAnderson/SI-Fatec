<?php
	class cursoController
	{
		private $param;
		public function __construct()
		{
			$this->param = Conexao::getInstancia();
		}
		public function listar()
		{
			//buscar os cursos no BD
			$cursoDAO = new cursoDAO($this->param);
			$retorno = $cursoDAO->buscar_todos_cursos();
			
			//Mostrar os cursos para o usuário
			require_once "Views/listar_cursos.php";
		}			
		public function cadastrar()
		{
			$msg = "";
			
			if($_POST)
			{
				//verificar os dados digitados
				if(empty($_POST["nome"]))
				{
					$msg = "Preencha o nome do curso";
					
				}
				else
				
				{
				//criar a instância do objeto curso
				$curso = new Curso(0, $_POST["nome"]);
				//criar uma instância cursoDAO
				$cursoDAO = new cursoDAO($this->param);
				//chamar o método inserir
				$cursoDAO->inserir($curso);
				
				//redirecionar para o listar
				header("location:/Curso/listar");
				die();
				}
			}
			//visão formulário cadastrar
			require_once "views/form_curso.php";
			
		}
		public function excluir()
		{
			if(isset($_GET["id"]))
			{
				$curso = new curso($_GET["id"]);
				$cursoDAO = new cursoDAO($this->param);
				$cursoDAO->excluir_curso($curso);
				header("location:/Curso/listar");
				die();
			}
		}
		public function alterar()
		{
			$msg = "";
			
			if($_POST)
			{
				//validar os dados
				if(empty($_POST["nome"]))
				{
					$msg = "Preencha o nome do curso";
					
				}
				
				else
				{
					$curso = new curso($_POST["id_curso"], $_POST["nome"]);
					$cursoDAO = new cursoDAO($this->param);
					$cursoDAO->alterar_curso($curso);
					header("location:/Curso/listar");
					die();
					
				}
			}//fim do post
			//buscar os dados do curso para alteração BD
			$curso = new curso($_GET["id"]);
			$cursoDAO = new cursoDAO($this->param);
			$retorno = $cursoDAO->buscar_um_curso($curso);
			//mostrar visão com os dados
			require_once "Views/edit_curso.php";
		}
	}
?>