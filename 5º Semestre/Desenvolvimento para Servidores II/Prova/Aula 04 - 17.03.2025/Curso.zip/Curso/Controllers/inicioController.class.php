<?php
	require_once "Models/componente.php";
	class inicioController
	{
		public function inicio()
		{
			$ul = new ul();
			$ul->setElemento(new li(new a("/Curso/inserir", "Novo Curso")));
			
			$ul->setElemento(new li(new a("/Curso/listar", "Cursos"))); 
			
			require_once "Views/menu.php";
		}
	}
?>