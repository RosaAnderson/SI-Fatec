<!doctype html>
<html>
	<head>
		<title>Adoção</title>
		<meta charset="UTF-8">
	</head>
	<body>
		<?php
			$ul->criar();
		?>
	</body>
</html>