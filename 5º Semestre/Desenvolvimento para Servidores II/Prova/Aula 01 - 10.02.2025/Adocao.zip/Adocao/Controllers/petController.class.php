<?php
	class petController
	{
		public function listar()
		{
			//buscar os pets no BD
			require_once "Models/Conexao.class.php";
			require_once "Models/petDAO.class.php";
			$petDAO = new petDAO();
			$retorno = $petDAO->buscar_todos_pets();
			
			//Mostrar os pets para o usuário
			require_once "Views/listar_pets.php";
		}			
		public function cadastrar()
		{
			if($_POST)
			{
				
			}
			//visão formulário cadastrar
		}
	}
?>