<?php
	class Proprietario
	{
		public function __construct(private int $idproprietario = 0, private string $nome = "", private string $celular = ""){}
		
		public function getIdproprietario()
		{
			return $this->idproprietario;
		}
		public function getNome()
		{
			return $this->nome;
		}
		public function getCelular()
		{
			return $this->celular;
		}
	}
?>