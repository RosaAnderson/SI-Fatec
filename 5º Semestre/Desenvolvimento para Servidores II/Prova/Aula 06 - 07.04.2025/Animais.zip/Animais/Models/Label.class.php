<?php
	class Label implements Componente
	{
		public function __construct(private string $texto = "", private string $for = ""){}
		
		public function criar()
		{
			echo "<label for='{$this->for}'>{$this->texto}</label>";
		}
	}
?>