<?php
	class animalDAO
	{
		public function __construct(private $db = null){}
		
		public function buscar_todos()
		{
			$sql = "SELECT a.*, p.nome as tutor FROM animais as a, proprietario as p WHERE a.idproprietario = p.idproprietario";
			try
			{
				$stm = $this->db->prepare($sql);
				$stm->execute();
				$this->db = null;
				return $stm->fetchAll(PDO::FETCH_OBJ);
			}
			catch(PDOException $e)
			{
				$this->db = null;
				die("Problema ao buscar animais");
			}
			
		}
		public function inserir($animal)
		{
			$sql = "INSERT INTO animais (nome, idade, cor, raca, idproprietario) VALUES(?,?,?,?,?)";
			try
			{
				$stm = $this->db->prepare($sql);
				$stm->bindValue(1, $animal->getNome());
				$stm->bindValue(2, $animal->getIdade());
				$stm->bindValue(3, $animal->getCor());
				$stm->bindValue(4, $animal->getRaca());
				$stm->bindValue(5, $animal->getProprietario()->getIdproprietario());
				$stm->execute();
				$this->db = null;
				return "Animal inserido com sucesso";
			}
			catch(PDOException $e)
			{
				$this->db = null;
				die("Erro ao inserir animal");
			}
		}
		public function buscar_Vacinas($animal)
		{
			$sql = "SELECT a.nome, v.descritivo, va.data_vacina FROM animais as a, vacinas as v, vacinas_animais as va WHERE a.idanimais = va.idanimais AND v.idvacinas = va.idvacinas AND va.idanimais = ?";
			try
			{
				$stm = $this->db->prepare($sql);
				$stm->bindValue(1, $animal->getIdanimal());
				$stm->execute();
				$this->db = null;
				return $stm->fetchAll(PDO::FETCH_OBJ);
			}
			catch(PDOException $e)
			{
				$this->db = null;
				die("Problema ao buscar vacinas do animal");
			}
		}
	}//fim da classe
?>