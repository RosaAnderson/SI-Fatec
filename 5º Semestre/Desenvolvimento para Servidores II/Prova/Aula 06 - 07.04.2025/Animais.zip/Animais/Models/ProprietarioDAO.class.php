<?php
	class ProprietarioDAO
	{
		public function __construct(private $db = null){}
		
		public function buscar_todos()
		{
			$sql = "SELECT * FROM proprietario";
			try
			{
				$stm = $this->db->prepare($sql);
				$stm->execute();
				$this->db = null;
				return $stm->fetchAll(PDO::FETCH_OBJ);
			}
			catch(PDOException $e)
			{
				$this->db = null;
				die("Problema ao buscar proprietários");
			}
		}
	}
	
?>