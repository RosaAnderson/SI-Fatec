<?php
	class Input implements Componente
	{
		public function __construct(private string $name = "", private string $type = "", private string $id = ""){}
		
		public function criar()
		{
			echo "<input type='{$this->type}' name='{$this->name}' id='{$this->id}'><br><br>";
		}
	}
?>