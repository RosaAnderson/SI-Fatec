<!doctype html>
<html>
	<head>
		<title>Animais</title>
		<meta charset="UTF-8">
	</head>
	<body>
		<h1>Animais</h1>
		<br>
		<table border="1">
			<tr>
				<th>Nome</th>
				<th>Raça</th>
				<th>Idade</th>
				<th>Cor</th>
				<th>Tutor</th>
				<th>Vacinas</th>
			</tr>
			<?php
				foreach($retorno as $dado)
				{
					echo "<tr>
					      <td>{$dado->nome}</td>
						  <td>{$dado->raca}</td>
						  <td>{$dado->idade}</td>
						  <td>{$dado->cor}</td>
						  <td>{$dado->tutor}</td>
						  <td>
							<a href='/Animais/listarVacinas?id={$dado->idanimais}'>Verificar</a>
							
						  </td>
						  </tr>";
				}
			?>
		</table>
		<br>
		<a href="/Animais/inserir">Novo Animal</a>
	</body>
</html>