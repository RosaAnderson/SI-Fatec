<!doctype html>
<html>
	<head>
		<title>Animais</title>
		<meta charset="UTF-8">
	</head>
	<body>
		<?php
		if(count($retorno) > 0)
		{
			echo "<h1>Animal -  {$retorno[0]->nome};</h1>";
		}
		else
		{
			echo "<h1>Animal não tomou nenhuma vacina</h1>";
		}
		?>
		<br>
		<table border="1">
			<tr>
				<th>Data da Aplicação</th>
				<th>Vacina</th>
				
			</tr>
			<?php
				foreach($retorno as $dado)
				{
					$data = explode("-", $dado->data_vacina);
					$data_vacina = $data[2] . "/" . $data[1] . "/" . $data[0];
					echo "<tr>
					      <td>{$data_vacina}</td>
						  <td>{$dado->descritivo}</td>
						  </tr>";
				}
			?>
		</table>
		
	</body>
</html>