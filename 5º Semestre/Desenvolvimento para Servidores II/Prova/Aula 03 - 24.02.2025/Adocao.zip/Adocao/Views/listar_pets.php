<!doctype html>
<html>
	<head>
		<title>Adoção</title>
		<meta charset="UTF-8">
	</head>
	<body>
		<h1>Lista de Pets</h1>
		<br>
		<table border="1">
			<tr>
				<th>Nome</th>
				<th>Idade</th>
				<th>Cor</th>
				<th>Porte</th>
				<th>Ações</th>
			</tr>
			<?php
				foreach($retorno as $dado)
				{
					echo "<tr>
					      <td>{$dado->nome}</td>
						  <td>{$dado->idade}</td>
						  <td>{$dado->cor}</td>
						  <td>{$dado->porte}</td>
						  <td>
	<a href='index.php?controle=petController&metodo=alterar&id={$dado->id_pet}'>Alterar</a>
							&nbsp;&nbsp;
							<a href='index.php?controle=petController&metodo=excluir&id={$dado->id_pet}'>Excluir</a>
						  </td>
						  </tr>";
				}
			?>
		</table>
	</body>
</html>