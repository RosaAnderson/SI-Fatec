<?php
	require_once "Models/Conexao.class.php";
	require_once "Models/petDAO.class.php";
	require_once "Models/Pet.class.php";
	class petController
	{
		public function listar()
		{
			//buscar os pets no BD
			$petDAO = new petDAO();
			$retorno = $petDAO->buscar_todos_pets();
			
			//Mostrar os pets para o usuário
			require_once "Views/listar_pets.php";
		}			
		public function cadastrar()
		{
			$msg = array("","","","");
			$erro = false;
			if($_POST)
			{
				//verificar os dados digitados
				if(empty($_POST["nome"]))
				{
					$msg[0] = "Preencha o nome do pet";
					$erro = true;
				}
				if($_POST["idade"] < 0)
				{
					$msg[1] = "Idade Inválida";
					$erro = true;
				}
				if(empty($_POST["cor"]))
				{
					$msg[2] = "Preencha as cores do pet";
					$erro = true;
				}
				if($_POST["porte"] == 0)
				{
					$msg[3] = "Escolha o porte do pet";
					$erro = true;
				}
				if(!$erro)
				{
				//criar a instância do objeto pet
				$pet = new Pet(0, $_POST["nome"], $_POST["idade"], $_POST["cor"], $_POST["porte"]);
				//criar uma instância petDAO
				$petDAO = new petDAO();
				//chamar o método inserir
				$petDAO->inserir($pet);
				
				//redirecionar para o listar
				header("location:index.php?controle=petController&metodo=listar");
				die();
				}
			}
			//visão formulário cadastrar
			require_once "views/form_pet.php";
			
		}
		public function excluir()
		{
			if(isset($_GET["id"]))
			{
				$pet = new Pet($_GET["id"]);
				$petDAO = new petDAO();
				$petDAO->excluir_pet($pet);
				header("location:index.php?controle=petController&metodo=listar");
			}
		}
		public function alterar()
		{
			$msg = array("","","","");
			$erro = false;
			if($_POST)
			{
				//validar os dados
				if(empty($_POST["nome"]))
				{
					$msg[0] = "Preencha o nome do pet";
					$erro = true;
				}
				if($_POST["idade"] < 0)
				{
					$msg[1] = "Idade Inválida";
					$erro = true;
				}
				if(empty($_POST["cor"]))
				{
					$msg[2] = "Preencha as cores do pet";
					$erro = true;
				}
				if($_POST["porte"] == 0)
				{
					$msg[3] = "Escolha o porte do pet";
					$erro = true;
				}
				if(!$erro)
				{
					$pet = new Pet($_POST["id_pet"], $_POST["nome"], $_POST["idade"], $_POST["cor"], $_POST["porte"]);
					$petDAO = new petDAO();
					$petDAO->alterar_pet($pet);
					header("location:index.php?controle=petController&metodo=listar");
					
				}
			}//fim do post
			//buscar os dados do pet para alteração BD
			$pet = new Pet($_GET["id"]);
			$petDAO = new petDAO();
			$retorno = $petDAO->buscar_um_pet($pet);
			//mostrar visão com os dados
			require_once "Views/edit_pet.php";
		}
	}
?>