<?php
	class Select implements Componente
	{
		public function __construct(private string $name = "", private array $elementos = array()){}
		
		public function criar()
		{
			echo "<select name='{$this->name}'>";
			foreach($this->elementos as $elemento)
			{
				$elemento->criar();
			}
			echo "</select>";
		}
		
		public function setElemento($elemento)
		{
			$this->elementos[] = $elemento;
		}
	}
?>