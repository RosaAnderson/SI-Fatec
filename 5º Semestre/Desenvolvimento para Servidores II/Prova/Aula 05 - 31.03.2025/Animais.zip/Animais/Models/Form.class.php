<?php
	class Form implements Componente
	{
		public function __construct(private string $action = "", private string $metodo = "", private array $elementos = array()){}
		
		public function criar()
		{
			echo "<form action='{$this->action}' method='{$this->metodo}'>";
			foreach($this->elementos as $elemento)
			{
				$elemento->criar();
			}
			
			
			
			echo "</form>";
		}
		
		public function setElemento($elemento)
		{
			$this->elementos[] = $elemento;
		}
	}
?>