<?php
	class Option implements Componente
	{
		public function __construct(private string $value = "", private string $texto = ""){}
		
		public function criar()
		{
			echo "<option value='{$this->value}'>{$this->texto}</option>";
		}
	}
?>