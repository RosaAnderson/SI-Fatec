<?php
	class Animal
	{
		public function __construct(private int $idanimal = 0, private string $nome = "", private int $idade = 0, private string $cor = "", private string $raca = "", private $proprietario = null){}
		
		public function getIdanimal()
		{
			return $this->idanimal;
		}
		public function getNome()
		{
			return $this->nome;
		}
		public function getIdade()
		{
			return $this->idade;
		}
		public function getRaca()
		{
			return $this->raca;
		}
		public function getProprietario()
		{
			return $this->proprietario;
		}
		public function getCor()
		{
			return $this->cor;
		}
	}
?>