<?php
	interface Componente
	{
		public function criar();
	}
?>