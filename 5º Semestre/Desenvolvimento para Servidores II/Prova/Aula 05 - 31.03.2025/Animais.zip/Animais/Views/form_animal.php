<!doctype html>
<html>
	<head>
		<title>Animais</title>
		<meta charset="UTF-8">
	</head>
	<body>
		<h1>Animal</h1>
		<?php
			$form->criar();
		?>
	</body>
</html>