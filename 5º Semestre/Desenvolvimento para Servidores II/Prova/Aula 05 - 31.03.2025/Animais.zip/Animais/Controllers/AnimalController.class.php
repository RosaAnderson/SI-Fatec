<?php
	require_once "Models/Componente.php";
	class AnimalController
	{
		private $param;
		public function __construct()
		{
			$this->param = Conexao::getInstancia();
		}
		public function listar()
		{
			$animalDAO = new animalDAO($this->param);
			$retorno = $animalDAO->buscar_todos();
			require_once "Views/listar_animais.php";
		}
		public function inserir()
		{
			$form = new Form("/Animais/inserir", "post");
			$form->setElemento(new Label("Nome:", "nome"));
			$form->setElemento(new Input("text", "nome", "nome"));
			$form->setElemento(new Label("Idade:", "idade"));
			$form->setElemento(new Input("text", "idade", "idade"));
			$form->setElemento(new Label("Raça:", "raca"));
			$form->setElemento(new Input("text", "raca", "raca"));
			$form->setElemento(new Label("Cor:", "cor"));
			$form->setElemento(new Input("text", "cor", "cor"));
			$form->setElemento(new Label("Proprietário:", "proprietario"));
			require_once "Views/form_animal.php";
		}
		public function listarVacinas()
		{
			if(isset($_GET["id"]))
			{
				$animal = new Animal($_GET["id"]);
				$animalDAO = new animalDAO($this->param);
				$retorno = $animalDAO->buscar_Vacinas($animal);
				require_once "Views/listar_vacinas.php";
			}
		}
	}//fim da classe
?>