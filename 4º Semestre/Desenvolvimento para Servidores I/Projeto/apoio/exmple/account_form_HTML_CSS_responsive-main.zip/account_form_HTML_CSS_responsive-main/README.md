# Formulário HTML e CSS responsivo

<p>Caso queira saber como foi feito este formulário, o vídeo está disponível no Youtube.<p>

<p>URL: https://youtu.be/Ph-60-pkAQM </p>

<br>

<p align="center">
  <img alt="methods" src="github/account_form.png" width="100%">
</p>
