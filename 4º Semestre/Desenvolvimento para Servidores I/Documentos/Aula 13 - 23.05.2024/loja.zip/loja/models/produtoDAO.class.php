<?php
	class produtoDAO extends Conexao
	{
		public function __construct()
		{
			parent:: __construct();
		}
		
		public function inserir($produto)
		{
			$sql = "INSERT INTO produtos (descritivo, status) VALUES(?,?)";
			//preparar frase
			$stm = $this->db->prepare($sql);
			//substituir o ponto de interrogação
			$stm->bindValue(1, $produto->getDescritivo());
			$stm->bindValue(2, $produto->getStatus());
			//executar a frase sql
			$stm->execute();
			//fechar a conexão
			$this->db = null;
			
		}
		public function alterar($produto)
		{
			$sql = "UPDATE produtos SET descritivo = ? WHERE idproduto = ?";
			$stm = $this->db->prepare($sql);
			$stm->bindValue(1, $produto->getDescritivo());
			$stm->bindValue(2, $produto->getIdproduto());
			$stm->execute();
			$this->db = null;
		}
		
		public function excluir($produto)
		{
			$sql = "DELETE FROM produtos WHERE idproduto = ?";
			$stm = $this->db->prepare($sql);
			$stm->bindValue(1, $produto->getIdproduto());
			$stm->execute();
			$this->db = null;
		}
		 
		public function buscar_todos()
		{
			//frase sql que será executada
			$sql = "SELECT p.*, c.descritivo FROM produtos as p, categorias as c WHERE p.idcategoria = c.idcategoria";
			//preparar frase
			$stm = $this->db->prepare($sql);
			//executar a frase sql
			$stm->execute();
			//fechar a conexão
			$this->db = null;
			//retornar o resultado da execução da frase sql
			return $stm->fetchAll(PDO::FETCH_OBJ);
		}
		public function buscar_uma_produto($produto)
		{
			$sql = "SELECT * FROM produtos WHERE idproduto = ?";
			
			$stm = $this->db->prepare($sql);
			$stm->bindValue(1,$produto->getIdproduto());
			$stm->execute();
			$this->db = null;
			return $stm->fetchAll(PDO::FETCH_OBJ);
		}
		public function alterar_status_produto($produto)
		{
			$sql = "UPDATE produtos SET status = ? WHERE idproduto = ?";
			$stm = $this->db->prepare($sql);
			$stm->bindValue(1, $produto->getStatus());
			$stm->bindValue(2, $produto->getIdproduto());
			$stm->execute();
			$this->db = null;
		}
	}//fim da classe produtoDAO
?>