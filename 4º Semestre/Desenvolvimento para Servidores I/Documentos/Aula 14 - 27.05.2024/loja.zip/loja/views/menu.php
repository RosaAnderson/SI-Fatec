<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Loja</title>
	</head>
	<body>
		<a href="listar_categorias.php">Categorias</a>
		<a href="listar_produtos.php">Produtos</a>
	</body>
</html>