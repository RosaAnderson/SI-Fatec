<?php
	class inicioController
	{
		public function inicio()
		{
			require_once "views/menu.html";
		}
	}
?>